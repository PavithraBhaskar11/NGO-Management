let mysql = require('mysql');

let connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Pavithra@2811',
  database: 'ngo_management'
});

//  connection.connect(function(err) {
// if (err) {
// return console.error('error: ' + err.message);
// }
//
// console.log('Connected to the MySQL server.');
// })

module.exports.connect = () => {
  connection.connect(err => {
    if (err) {
      console.log(err)
      return
    }
    console.log('The database is Connected')
  })
}

module.exports.loginUser = (email, password) => {
  return new Promise((resolve, reject) => {
    connection.query("SELECT * FROM login WHERE email=?", [email], (err, rows) => {
      console.log("err", err);
      console.log("rows", rows);
      if (err) {

        return reject(err)
      }
      if (rows.length === 0) {
        console.log("Inside If")
        return reject("Invalid email ID..")
      }
      if (password === rows[0].password) {
        return resolve(rows[0].sl_no)
      } else {
        return reject("Invalid Password")
      }
    })
  })
}

module.exports.signUpUser = (username, address, mobileNumber, email, password, type, preferredCity) => {
  return new Promise((resolve, reject) => {
    connection.beginTransaction(err => {
      if (err) {
        return reject(err)
      }

      connection.query("INSERT INTO users(u_name, address ,phone_number ,email ,password, type, pref_city) VALUES(?,?,?,?,?,?,?) ", [username, address, mobileNumber, email, password, type, preferredCity], err => {
        if (err) {
          return reject(err)
        }

        connection.query("INSERT Into login(email , password, type , u_name) VALUES(?,?,?,?) ", [email, password, type, username], err => {
          if (err) {
            return reject(err)
          }
          connection.commit();
          resolve("User Added Successfully")
        })
      })
    })
  })
}