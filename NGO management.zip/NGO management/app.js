const express = require('express');
const bodyParser = require('body-parser');
const database = require('./database/database');
const session = require('express-session');
var app = express();

const {
  isUserLogedIn
} = require('./isUserLogedIn');

app.use(express.static('static'));
app.use(bodyParser.urlencoded({
  extended: true
}));

app.set('view engine', 'ejs');

app.use(session({
  name: 'code_fury',
  secret: "Secret",
  resave: false,
  saveUninitialized: false,
}))


app.get('/', function(req, res) {
  res.render('home/index');
})
app.get('/register', function(req, res) {
  res.render('home/register');
})

app.get('/vol_register', function(req, res) {
  res.render('home/volunteerRegisteration', {
    err: null
  });
})

app.get('/spo_register', function(req, res) {
  res.render('home/sponsorRegisteration', {
    err: null
  });
})

app.get('/login', function(req, res) {
  res.render('home/login', {
    err: null
  });
})

app.post('/login', (req, res) => {
  let {
    email,
    password
  } = req.body
  console.log(`email=>${email}, password->${password}`)
  database.loginUser(email, password)
    .then((sl_no) => {
      console.log("simply");
      req.session.isUserLogedIn = true;
      //  req.session.sl_no = sl_no
      //Render Home page
      console.log("home...")
      res.redirect('/')
    })
    .catch(err => {
      console.log("err", err);
      res.render('home/login', {
        err: err
      })
    }) // Render Login Page

})
app.post('/register', (req, res) => {
  let {
    username,
    address,
    mobileNumber,
    email,
    password,
    preferredCity,
    type
  } = req.body
  database.signUpUser(username, address, mobileNumber, email, password, type, preferredCity)
    .then((sl_no) => {
      res.render('home/login', {
        err: null
      })
    })
    .catch(err => {
      res.render('home/login', {
        err: err
      })
    }) // Render Login Page
  // res.render('login', {
  //   err: null
  // })
})

app.listen(3000, function() {
  console.log("Server is running on port 3000");
})




// function requesting(requestNumber) {
//   console.log("request number:", requestNumber);
//
//   gettingResponse(function() {
//
//     console.log(requestNumber, "request accepted");
//   })
//
//
// }
//
// function gettingResponse(callback) {
//   setTimeout(callback, 5000);
// }
// requesting(1);
// requesting(2);
// requesting(3);
// requesting(4);
// requesting(5);
//
// app.listen(3000, function() {
//   console.log("Running");
// })